// @dart=2.9
import 'package:flutter/material.dart';
import 'package:gastos_mensais/view/cadastro_gasto_mensal.dart';
import 'package:gastos_mensais/view/lista_gasto_mensal.dart';
import 'package:gastos_mensais/view/pesquisa_data.dart';
void main() {
  runApp(MaterialApp(
    home: //Pesquisa(),
    ListaGastoMensal(),
    // Cadastro(),
    theme: ThemeData(
        hintColor: Colors.purple,
        primaryColor: Colors.white,
        inputDecorationTheme: InputDecorationTheme(
          enabledBorder:
          OutlineInputBorder(borderSide: BorderSide(color:
          Colors.white)),
          focusedBorder:
          OutlineInputBorder(borderSide: BorderSide(color:
          Colors.purple)),
          hintStyle: TextStyle(color: Colors.purple),
        )),
  ));
}