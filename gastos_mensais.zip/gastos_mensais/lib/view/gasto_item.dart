import 'package:flutter/material.dart';
import 'package:gastos_mensais/model/gasto.dart';
class GastoItem extends StatelessWidget {
  final GastoMensal _gastoMensal;
  GastoItem(this._gastoMensal);
  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.purple,
      child: ListTile(
        title: Text(
          _gastoMensal.finalidade,
          style: TextStyle(
            fontSize: 16.0,
          ),
        ),
        subtitle: Text(
          _gastoMensal.valor.toStringAsFixed(2),
          style: TextStyle(
            fontSize: 12.0,
          ),
        ),
      ),
    );
  }
}