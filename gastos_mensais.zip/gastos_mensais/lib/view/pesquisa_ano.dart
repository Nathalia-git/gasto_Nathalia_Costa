
import 'package:gastos_mensais/model/gasto.dart';
import 'package:gastos_mensais/view/pesquisa_mes.dart';
import 'package:flutter/material.dart';
import 'package:gastos_mensais/view/pesquisa_data.dart';

import 'gasto_item.dart';


class PesquisaAno extends StatefulWidget {
  @override
  _PesquisaAnoState createState() => _PesquisaAnoState();
}

class _PesquisaAnoState extends  State<PesquisaAno> {
   DateTime now = new DateTime.now();
   var berlinWallFellDate = new DateTime.utc(1989,11,20);
   final List<GastoMensal> gasto = <GastoMensal>[];


  TextEditingController _anoController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate, // Refer step 1
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

   TextEditingController _id = TextEditingController();
   TextEditingController _ano = TextEditingController();
   TextEditingController _finalidade = TextEditingController();
   TextEditingController _valor = TextEditingController();
   TextEditingController _tipo_gasto = TextEditingController();
   TextEditingController _mes = TextEditingController();

   _listar(){
     // ignore: unrelated_type_equality_checks
     var data = [gasto].any((el) => el == _anoController);
         return data;
     }
   _calcular(){
     setState(() {
       double valor_gasto = double.parse(gasto[_valor].text);
       double total = 0;
       total = total + valor_gasto;
       print("Total: " + total.toStringAsFixed(2));
     }
     );
   }
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black, appBar: AppBar(
      title: Text("\$ Pesquisa por Ano \$"),
      backgroundColor: Colors.purple,
      centerTitle: true,
      leading: new IconButton(
        icon: new Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PesquisaMes()),
          );
        },
      ),
    ),

      body: SingleChildScrollView(
        child: Column(
            children: <Widget>[
        Padding(
        padding: const EdgeInsets.all(10.0),
        child: TextFormField(
          controller: _anoController,
          decoration: InputDecoration(
              labelText: "Ano"
          ),
          validator: (value) {
            if (berlinWallFellDate.compareTo(selectedDate)>0) return  value.toString();
          },
        ),

      ),

      Padding(
        padding: const EdgeInsets.all(16.0),
        child: SizedBox(
          width: double.maxFinite,
          // ignore: deprecated_member_use
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.purple
            ),
            child: Text("Pesquisar"
            ),
            onPressed: () {
              _listar();
              _calcular();
            },
          ),
        )
      ),
      ],
    ),
    ),
    floatingActionButton: FloatingActionButton(
    onPressed: (){
    Navigator.of(context).push(
    MaterialPageRoute(
    builder: (context) => Pesquisa(),
    ),
    );
    },
    child: Icon(Icons.trending_neutral),
    backgroundColor: Colors.purple,
    ),
    );

  }

  }

