
import 'package:gastos_mensais/model/gasto.dart';
import 'package:gastos_mensais/view/pesquisa_ano.dart';
import 'package:gastos_mensais/view/pesquisa_mes.dart';
import 'package:flutter/material.dart';


class Pesquisa extends StatefulWidget {
  @override
  _PesquisaState createState() => _PesquisaState();
}

class _PesquisaState extends  State<Pesquisa> {
  DateTime now = new DateTime.now();

  final List<GastoMensal> gasto = <GastoMensal>[];
  TextEditingController _data2Controller = TextEditingController();
  TextEditingController _data1Controller = TextEditingController();
  var selectedDate =DateTime.now();
  var berlinWallFellDate = new DateTime.utc(1989,11,20);
  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate, // Refer step 1
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }
  _listar(){
    // ignore: unrelated_type_equality_checks
    var data1= [gasto].any((el) => el == _data1Controller);
    var data2 = [gasto].any((el) => el == _data2Controller);

  }
  _calcular(){
    setState(() {
      double valor_gasto = double.parse(gasto[_valor].text);
      double total = 0;
      total = total + valor_gasto;
      print("Total: " + total.toStringAsFixed(2));
    }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black, appBar: AppBar(
      title: Text("\$ Pesquisa por Intervalo \$"),
      backgroundColor: Colors.purple,
      centerTitle: true,
      leading: new IconButton(
        icon: new Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PesquisaMes()),
          );
        },
      ),
    ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextFormField(
                controller: _data1Controller,
                decoration: InputDecoration(
                    labelText: "Data Inicial"
                ),
                validator: (value) {
                  if (berlinWallFellDate.compareTo(selectedDate)>0) return  value.toString();
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextFormField(
                controller: _data2Controller,
                decoration: InputDecoration(
                    labelText: "Data Final"
                ),
                validator: (value) {
                  if (berlinWallFellDate.compareTo(selectedDate)>0) return  value.toString();
                },
              ),
            ),
            Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.maxFinite,
                  // ignore: deprecated_member_use
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.purple
                    ),
                    child: Text("Pesquisar"
                    ),
                    onPressed: () {
                      _listar();
                      _calcular();
                    },
                  ),
                )
            ),
          ],
        ),
      ),
    );

  }

}