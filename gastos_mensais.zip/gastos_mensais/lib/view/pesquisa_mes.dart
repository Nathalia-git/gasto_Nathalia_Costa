
import 'package:flutter/material.dart';
import 'package:gastos_mensais/controller/gasto_controller.dart';
import 'package:gastos_mensais/model/gasto.dart';
import 'package:gastos_mensais/view/cadastro_gasto_mensal.dart';
import 'package:gastos_mensais/view/pesquisa_ano.dart';


class PesquisaMes extends StatefulWidget {
  @override
  _PesquisaMesState createState() => _PesquisaMesState();
}

class _PesquisaMesState extends  State<PesquisaMes> {
  DateTime selectedDate = DateTime.now();
  var berlinWallFellDate = new DateTime.utc(1989,11,20);
  final List<GastoMensal> gasto = <GastoMensal>[];
  GastoController _gastoController = GastoController();
  TextEditingController _id = TextEditingController();
  TextEditingController _ano = TextEditingController();
  TextEditingController _finalidade = TextEditingController();
  TextEditingController _valor = TextEditingController();
  TextEditingController _tipo_gasto = TextEditingController();

//  var _mesSelecionado = 'Janeiro';
  TextEditingController _mesController = TextEditingController();


 _listar(){
    // ignore: unrelated_type_equality_checks
    var data = [gasto].any((el) => el == _mesController);
    return data;
  }
  _calcular(){
    setState(() {
      double valor_gasto = double.parse(gasto[_valor].text);
      double total = 0;
      total = total + valor_gasto;
      print("Total: " + total.toStringAsFixed(2));
    }
      );
    }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black, appBar: AppBar(
    title: Text("\$ Pesquisa Mes \$"),
    backgroundColor: Colors.purple,
    centerTitle: true,
    leading: new IconButton(
    icon: new Icon(Icons.arrow_back),
    onPressed: () {
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => Cadastro()),
    );
    },
    ),
    ),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextFormField(
                controller: _mesController,
                decoration: InputDecoration(
                    labelText: "Mes"
                ),
                validator: (value) {
                  if (berlinWallFellDate.compareTo(selectedDate)>0) return  value.toString();
                },
              ),

            ),

            Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.maxFinite,
                  // ignore: deprecated_member_use
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.purple
                    ),
                    child: Text("Pesquisar"
                    ),
                    onPressed: () {
                      _listar();
                      _calcular();
                    },
                  ),
                )
            ),
          ],
        ),
      ),

    floatingActionButton: FloatingActionButton(
    onPressed: (){
    Navigator.of(context).push(
    MaterialPageRoute(
    builder: (context) => PesquisaAno(),
    ),
    );
    },
    child: Icon(Icons.trending_neutral),
    backgroundColor: Colors.purple,
    ),
    );
  }

}