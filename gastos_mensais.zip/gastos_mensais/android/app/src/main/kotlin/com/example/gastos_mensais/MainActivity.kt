package com.example.gastos_mensais

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
